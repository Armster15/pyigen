# pyigen
v1.0.1.1 created by Armaan Aggarwal on May 15, 2019

This is a little package that can generate a pyinstaller setup.py script to 
turn your program into an .exe or .app file!

To know how to use this module, import pyigen and then call: 'pyigen.manual()'
	
View this package at GitHub at https://github.com/armaan115/pyigen